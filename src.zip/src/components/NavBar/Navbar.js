import React from 'react';
import "./Navbar.css";
import logo from '../../static/images/logos/logo.png';

const navbar = (props) => {
    return (
        <div className="nav-bar" style={{textAlign: "left"}}>
            <img src={logo} alt="ACME_LOGO"/>
        </div>
    );
};

export default navbar;