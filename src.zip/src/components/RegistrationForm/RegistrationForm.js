import React from 'react';
import "./RegistrationForm.css";
import GenderType from './GenderType/GenderType';

const registrationForm = (props) => {
    return (
        <form className="registration-form" onSubmit={props.registerApplicant}>
            <div className="columns">
                <p className="label">First Name</p>
                <input type="text" placeholder="-- Type here --" 
                       value={props.studentData.firstName}
                       onChange={props.firstNameUpdate} required />
            </div>
            <div className="columns">
                <p className="label">Last Name</p>
                <input type="text" placeholder="-- Type here --" 
                       value={props.studentData.lastName}
                       onChange={props.lastNameUpdate} required/>
            </div>
            <div className="columns">
                <p className="label">Gender</p>
                <GenderType setGender={props.setGender}
                            updateGender={props.updateGender}
                            studentData={props.studentData}/>
            </div>
            <hr/>
            <input className="submit" type="submit" value="Register"/>
        </form>
    )
}

export default registrationForm;