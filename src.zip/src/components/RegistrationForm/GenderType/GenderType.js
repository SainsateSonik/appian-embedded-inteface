import React from 'react';
import "./GenderType.css";

const checked = {
    backgroundColor: "rgba(0, 128, 128, 0.37)",
    color: "#222"
};

const unchecked = {
    backgroundColor: "white",
    color: "#555"
};

const genderType = (props) => {
    const checkedGender = props.studentData.gender;

    return(
        <div className="gender-selection">
            <div className="gender-type">
                <div className="wrapper"
                     style={checkedGender === "Male" ? checked : unchecked }
                     onClick={props.updateGender.bind(null, "Male")}>
                    <input type="radio" name="gender" value="Male" required
                           onChange={props.setGender} checked={checkedGender === "Male"} />
                    <span>Male</span>
                </div>
            </div>
            <div className="gender-type">
                <div className="wrapper"
                     style={checkedGender === "Female" ? checked : unchecked }
                     onClick={props.updateGender.bind(null, "Female")}>
                    <input type="radio" name="gender" value="Female" required
                           onChange={props.setGender} checked={checkedGender === "Female"}/>
                    <span>Female</span>
                </div>
            </div>
            <div className="gender-type">
                <div className="wrapper"
                     style={checkedGender === "Transgender" ? checked : unchecked }
                     onClick={props.updateGender.bind(null, "Transgender")}>
                    <input type="radio" name="gender" value="Transgender" required
                           onChange={props.setGender} checked={checkedGender === "Transgender"}/>
                    <span>Other</span>
                </div>
            </div>
        </div>
    );
};

export default genderType;