import React, { Component } from 'react';
import './App.css';
import axios from 'axios';

import RegistrationForm from './components/RegistrationForm/RegistrationForm';
import Navbar from './components/NavBar/Navbar';

class App extends Component {
  state = {
    studentData : {
      firstName : "",
      lastName : "",
      gender : ""
    }
  }

  registerApplicant = (event) => {
    event.preventDefault();
    const dataToPost = this.state.studentData;

    axios.post("https://capgemini-spain-1016.appiancloud.com/suite/webapi/admission-application", dataToPost, {
      auth: {
        username: 'Sonik',
        password: '#1sainsubawa#1'
      },
    })
    .then((response) => {
      console.log("Yup");
      console.log(response);
    })
    .catch((error) => {
      console.log("Naa");
      console.log(error);
    });
  }

  firstNameUpdate = (event) => {
    const studentData = {...this.state.studentData};
    studentData.firstName = event.target.value;
    this.setState({studentData});
  }

  lastNameUpdate = (event) => {
    const studentData = {...this.state.studentData};
    studentData.lastName = event.target.value;
    this.setState({studentData});
  }

  setGender = (event) => {
    const studentData = {...this.state.studentData};
    studentData.gender = event.target.value;
    this.setState({studentData});
  }

  updateGender = (gender) => {
    const studentData = {...this.state.studentData};
    studentData.gender = gender;
    this.setState({studentData})
  }

  render() {
    return (
      <div className="App">
        <Navbar />
        <RegistrationForm registerApplicant={this.registerApplicant}
                          firstNameUpdate={this.firstNameUpdate}
                          lastNameUpdate={this.lastNameUpdate}
                          setGender={this.setGender}
                          updateGender={this.updateGender}
                          studentData={this.state.studentData}/>
      </div>
    );
  }
}

export default App;
